#  - MOPA — Medical Oncology Prior Authorization v0.1.0

## : 

Profile: [Primary Cancer Condition Profile](http://hl7.org/fhir/us/mcode/STU4/StructureDefinition-mcode-primary-cancer-condition.html)

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**category**: Problem List Item

**code**: Malignant neoplasm of breast

**subject**: [Jane Smith (official) Female, DoB: 1968-04-15 ( http://hospital.example.org/patients#MRN-78432)](Patient-OCPAPatientExample.md)

**onset**: 2026-02-10

